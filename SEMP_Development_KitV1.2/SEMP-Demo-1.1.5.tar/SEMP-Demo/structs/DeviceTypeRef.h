#ifndef DEVICETYPEREF_H_
#define DEVICETYPEREF_H_

#include "../SEMPCommon.h"

namespace SEMP
{

struct DeviceTypeRef
{
   static const xs_string AirConditioning;
   static const xs_string Charger;
   static const xs_string DishWasher;
   static const xs_string Dryer;
   static const xs_string ElectricVehicle;
   static const xs_string EVCharger;
   static const xs_string Freezer;
   static const xs_string Fridge;
   static const xs_string Heater;
   static const xs_string HeatPump;
   static const xs_string Motor;
   static const xs_string Pump;
   static const xs_string WashingMachine;
   static const xs_string Other;
};

}

#endif
