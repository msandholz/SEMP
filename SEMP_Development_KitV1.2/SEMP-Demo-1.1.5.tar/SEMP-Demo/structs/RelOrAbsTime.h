#ifndef RELORABSTIME_H_
#define RELORABSTIME_H_

#include "../SEMPCommon.h"

namespace SEMP
{

/*! Simple type RelOrAbsTime
 * Type representing timestamps that can either be relative (seconds relative to the current point of time) or absolute (Unix timestamp UTC in seconds since 01.01.1970).
        The device specifies the interpretation globally with the DeviceInfo.Capabilities.Timestamps element.
        Devices that do not have a synchronized clock (with time server protocols like NTP or radio control like DCF77) or do not have a reliable absolute time source should use relative timestamps.
 * 
 */
typedef xs_long RelOrAbsTime;

}

#endif
