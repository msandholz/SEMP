#include "MessageTypeRef.h"
using namespace SEMP;

const xs_string MessageTypeRef::InvalidTimeframe = "InvalidTimeframe";
const xs_string MessageTypeRef::DeviceControlIgnored = "DeviceControlIgnored";
const xs_string MessageTypeRef::Other = "Other";
