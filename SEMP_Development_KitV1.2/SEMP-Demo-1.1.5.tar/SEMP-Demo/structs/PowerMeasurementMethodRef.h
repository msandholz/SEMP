#ifndef POWERMEASUREMENTMETHODREF_H_
#define POWERMEASUREMENTMETHODREF_H_

#include "../SEMPCommon.h"

namespace SEMP
{

struct PowerMeasurementMethodRef
{
   static const xs_string Measurement;
   static const xs_string Estimation;
   static const xs_string None;
};

}

#endif
