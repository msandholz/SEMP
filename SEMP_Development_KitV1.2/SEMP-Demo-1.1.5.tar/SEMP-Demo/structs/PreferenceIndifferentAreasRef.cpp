#include "PreferenceIndifferentAreasRef.h"
using namespace SEMP;

const xs_string PreferenceIndifferentAreasRef::NoPreference = "NoPreference";
const xs_string PreferenceIndifferentAreasRef::Early = "Early";
const xs_string PreferenceIndifferentAreasRef::Late = "Late";
