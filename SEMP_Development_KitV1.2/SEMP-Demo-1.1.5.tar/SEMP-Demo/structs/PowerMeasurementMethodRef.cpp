#include "PowerMeasurementMethodRef.h"
using namespace SEMP;

const xs_string PowerMeasurementMethodRef::Measurement = "Measurement";
const xs_string PowerMeasurementMethodRef::Estimation = "Estimation";
const xs_string PowerMeasurementMethodRef::None = "None";
