#include "CapPowerMeasurement.h"
#include "../SEMPCommon.h"

namespace SEMP
{

CapPowerMeasurement::CapPowerMeasurement()
{
}


void CapPowerMeasurement::serializeXML(std::stringstream &sstream, int level_) const
{
   if (isSet("method")) {
         sstream << indentXML(level_) << "<Method>";
         sstream << escapeString(method);
         sstream << "</Method>\n";
   }
}

bool CapPowerMeasurement::validateXMLSchema(std::string &errElement_) const
{
   if (!isSet("method")) { errElement_ = "method"; return false; }
   return true;
}

}
