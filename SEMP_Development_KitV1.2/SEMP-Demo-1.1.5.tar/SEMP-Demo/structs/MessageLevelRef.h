#ifndef MESSAGELEVELREF_H_
#define MESSAGELEVELREF_H_

#include "../SEMPCommon.h"

namespace SEMP
{

struct MessageLevelRef
{
   static const xs_string Info;
   static const xs_string Warn;
   static const xs_string Error;
};

}

#endif
