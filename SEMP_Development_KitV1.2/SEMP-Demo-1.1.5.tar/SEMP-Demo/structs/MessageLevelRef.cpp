#include "MessageLevelRef.h"
using namespace SEMP;

const xs_string MessageLevelRef::Info = "Info";
const xs_string MessageLevelRef::Warn = "Warn";
const xs_string MessageLevelRef::Error = "Error";
