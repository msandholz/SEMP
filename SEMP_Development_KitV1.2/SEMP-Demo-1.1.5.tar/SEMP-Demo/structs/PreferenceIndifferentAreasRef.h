#ifndef PREFERENCEINDIFFERENTAREASREF_H_
#define PREFERENCEINDIFFERENTAREASREF_H_

#include "../SEMPCommon.h"

namespace SEMP
{

struct PreferenceIndifferentAreasRef
{
   static const xs_string NoPreference;
   static const xs_string Early;
   static const xs_string Late;
};

}

#endif
