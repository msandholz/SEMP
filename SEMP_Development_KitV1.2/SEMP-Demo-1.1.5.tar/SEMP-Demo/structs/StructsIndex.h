#ifndef STRUCTSINDEXSEMP_H_
#define STRUCTSINDEXSEMP_H_

#include "Device2EM.h"
#include "EM2Device.h"

namespace SEMP {

typedef version_t<1,1,5> XSDVersion;


}

#endif
