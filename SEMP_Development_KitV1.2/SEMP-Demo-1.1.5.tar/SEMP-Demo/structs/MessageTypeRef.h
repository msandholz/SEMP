#ifndef MESSAGETYPEREF_H_
#define MESSAGETYPEREF_H_

#include "../SEMPCommon.h"

namespace SEMP
{

struct MessageTypeRef
{
   static const xs_string InvalidTimeframe;
   static const xs_string DeviceControlIgnored;
   static const xs_string Other;
};

}

#endif
