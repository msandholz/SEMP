#include "MessageData.h"
#include "../SEMPCommon.h"
#include "DeviceId.h"
#include "RelOrAbsTime.h"

namespace SEMP
{

MessageData::MessageData()
{
}


void MessageData::serializeXML(std::stringstream &sstream, int level_) const
{
   if (isSet("deviceId")) {
         sstream << indentXML(level_) << "<DeviceId>";
         sstream << deviceId;
         sstream << "</DeviceId>\n";
   }
   if (isSet("timestamp")) {
         sstream << indentXML(level_) << "<Timestamp>";
         sstream << timestamp;
         sstream << "</Timestamp>\n";
   }
}

bool MessageData::validateXMLSchema(std::string &errElement_) const
{
   return true;
}

}
