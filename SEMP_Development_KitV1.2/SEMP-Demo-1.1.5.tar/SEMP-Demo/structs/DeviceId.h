#ifndef DEVICEID_H_
#define DEVICEID_H_

#include "../SEMPCommon.h"

namespace SEMP
{

typedef xs_string DeviceId;

}

#endif
