#ifndef STATUSREF_H_
#define STATUSREF_H_

#include "../SEMPCommon.h"

namespace SEMP
{

struct StatusRef
{
   static const xs_string On;
   static const xs_string Off;
   static const xs_string Offline;
};

}

#endif
