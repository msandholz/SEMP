#include "StatusRef.h"
using namespace SEMP;

const xs_string StatusRef::On = "On";
const xs_string StatusRef::Off = "Off";
const xs_string StatusRef::Offline = "Offline";
