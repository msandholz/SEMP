#include "DeviceTypeRef.h"
using namespace SEMP;

const xs_string DeviceTypeRef::AirConditioning = "AirConditioning";
const xs_string DeviceTypeRef::Charger = "Charger";
const xs_string DeviceTypeRef::DishWasher = "DishWasher";
const xs_string DeviceTypeRef::Dryer = "Dryer";
const xs_string DeviceTypeRef::ElectricVehicle = "ElectricVehicle";
const xs_string DeviceTypeRef::EVCharger = "EVCharger";
const xs_string DeviceTypeRef::Freezer = "Freezer";
const xs_string DeviceTypeRef::Fridge = "Fridge";
const xs_string DeviceTypeRef::Heater = "Heater";
const xs_string DeviceTypeRef::HeatPump = "HeatPump";
const xs_string DeviceTypeRef::Motor = "Motor";
const xs_string DeviceTypeRef::Pump = "Pump";
const xs_string DeviceTypeRef::WashingMachine = "WashingMachine";
const xs_string DeviceTypeRef::Other = "Other";
