***************************************************************************
* SEMP Communication Demo                                                 *
***************************************************************************
* Copyright (c) 2008-2014                                                 *
* SMA Solar Technology AG                                                 *
* All rights reserved.                                                    *
* This design is confidential and proprietary of SMA Solar Technology AG. *
***************************************************************************

This application demonstrates the communication aspects of the SEMP protocol.

==== Files ====================================

The applications are implemented in C++.

Source files:
  * Generic files:
    - base/*: Base helper classes for logging, threads, ...
    - http/*: generic HTTP-client and server implementations
    - ssdp/*: UPnP SSDP implementation
  * SEMP specific files:
    - structs/*: SEMP datastructures auto-generated from the SEMP XSD-file
    - EnergyManager.cpp: implementation of an Energy Manager (e.g. Sunny Home Manager)
    - GatewaySimulator.cpp: implementation of a SEMP Gateway (representing controllable devices like washing-machines, heat-pumps, car-chargers, ...)
    - handlers/*: SEMP Gateway message handlers (gateway behavior is specified by the used handler)

Note for Java programmers:
 If instead of C++ Java should be used as a programming language, JAXB can be used to generate 
 datastructures (with automatic XML de-/serialization) from the XSD file 
 (see the xjc tool coming with JAXB or Java 6 SE).
 For the webserver implementation Jersey (http://jersey.java.net/) could be used, which also 
 provides support for the auto-generated JAXB datastructures.

==== Build ====================================

The examples can be build under Linux (native or in a in virtual machine like VirtualBox) or in a Cygwin (http://www.cygwin.com/) environment under Windows.
The demo applications do not depend on external libraries. You will only need the GCC C++ compiler (g++) and make. 
Linux might already come with packages for these tools installed. Otherwise you can install them via the package manager coming with your Linux distribution.
For Cygwin you have to install the packages "gcc-g++", "gcc4-g++" and "make" (all in the category "Devel") via the setup utility (setup.exe).
If the Cygwin installer asks you to install further packages that are required by those packages, answer the question with yes.

To build the applications, run "make" in the base directory of the demo. This will generate the executables EnergyManager and Gateway.


==== Execution ================================

Execute the programs EnergyManager and Gateway to start the demo. It is recommended to execute the applications in 
different console windows.
In the window of the EnergyManager application you can step through the demo szenario and see the received SEMP and UPnP-SSDP data structures.
In the window of the Gateway application you can watch the HTTP-Requests and Responses received and sent by the internal HTTP-Server 
and actions triggered on the devices by the SEMP requests from the EnergyManager.

