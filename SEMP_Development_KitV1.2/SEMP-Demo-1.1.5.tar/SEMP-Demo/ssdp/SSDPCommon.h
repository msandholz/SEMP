/***************************************************************************
 *              SMA Solar Technology AG, 34266 Niestetal, Germany
 ***************************************************************************
 *
 *  Copyright (c) 2008-2014
 *  SMA Solar Technology AG
 *  All rights reserved.
 *  This design is confidential and proprietary of SMA Solar Technology AG.
 *
 ***************************************************************************/

#ifndef SSDPCOMMON_H_
#define SSDPCOMMON_H_

/*
 * Helper macro for stringification of defines
 */
#undef _STR
#undef STR
#define _STR(x) #x
#define STR(x) _STR(x)

/*
 * UPnP SSDP definitions
 */

#define SSDP_MCAST_IP    "239.255.255.250"
#define SSDP_MCAST_PORT  1900

#endif /* SSDPCOMMON_H_ */
