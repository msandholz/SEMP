
$(function() {
	$(".sempElems").multiAccordion();
	$(".sempSequence").multiAccordion();
	$(".sempChoice-content").multiAccordion();
});
