$.fn.multiAccordion = function() {
	$(this).addClass("ui-accordion ui-widget ui-helper-reset");
	$('> h3', this)
		.addClass("ui-accordion-header ui-accordion-header-inactive ui-helper-reset ui-state-default ui-corner-all ui-accordion-icons")
		.hover(function() { $(this).toggleClass("ui-state-hover"); })
		.prepend('<span class="ma-header-icon-left ui-icon ui-icon-triangle-1-e"></span>')
		.prepend('<span class="ma-header-icon-right ui-icon ui-icon-extlink"></span>')
		.click(function() {
			$(this)
				.toggleClass("ui-accordion-header-active ui-accordion-header-inactive ui-state-active ui-state-default ui-corner-all ui-corner-top")
				.find("> .ui-icon").toggleClass("ui-icon-triangle-1-e ui-icon-triangle-1-s").end()
				.next().toggleClass("ui-accordion-content-active").toggle();
			return false;
		})
		.next()
			.addClass("ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom")
			.css("display", "block")
			.hide()
		.end();
	$('.ma-header-icon-right', this).click(function() {
		var bar = $(this).parent();
		var content = bar.next();
		var accordion = bar.parent();
		if (accordion.hasClass("ma-expanded")) {
			if (bar.hasClass("ui-accordion-header-active"))
				bar.trigger("click");
			content.find(".ui-accordion-header-active").trigger("click");
			content.find(".ui-accordion").removeClass("ma-expanded");
			accordion.removeClass("ma-expanded");
		} else {
			if (bar.hasClass("ui-accordion-header-inactive"))
				bar.trigger("click");
			content.find(".ui-accordion-header-inactive").trigger("click");
			content.find(".ui-accordion").addClass("ma-expanded");
			accordion.addClass("ma-expanded");
		}
		return false;
	});
};
